export const ReveiwList = [
  {
    contentsid: 'CNTS_000000000022852',
    id: 'test1',
    content: '대충 잘 갔다옴',
    img: '../test.jpg',
    date: '대충 현재 날짜 넣기',
    score: 5
  },
  {
    contentsid: 'CNTS_000000000022852',
    id: 'test12',
    content: '대충 잘 갔다옴3',
    img: '../test.jpg',
    date: '대충 현재 날짜 넣기',
    score: 5
  },
  {
    contentsid: 'CNTS_000000000022852',
    id: 'test1',
    content: '대충 잘 갔다옴',
    img: '../test.jpg',
    date: '대충 현재 날짜 넣기',
    score: 5
  },
  {
    contentsid: 'CNTS_000000000022852',
    id: 'test12',
    content: '대충 잘 갔다옴3',
    img: '../test.jpg',
    date: '대충 현재 날짜 넣기',
    score: 5
  },
  {
    contentsid: '123',
    id: 'test2',
    content: '2 잘 갔다옴',
    img: '2 이미지 url',
    date: '3 현재 날짜 넣기',
    score: 5
  },
  {
    contentsid: 'CNTS_000000000022852',
    id: 'test1',
    content: '대충 잘 갔다옴',
    img: '../test.jpg',
    date: '대충 현재 날짜 넣기',
    score: 5
  },
  {
    contentsid: 'CNTS_000000000022852',
    id: 'test12',
    content: '대충 잘 갔다옴3',
    img: '../test.jpg',
    date: '대충 현재 날짜 넣기',
    score: 5
  },
  {
    contentsid: 'CNTS_000000000022852',
    id: 'test1',
    content: '대충 잘 갔다옴',
    img: '../test.jpg',
    date: '대충 현재 날짜 넣기',
    score: 5
  },
  {
    contentsid: 'CNTS_000000000022852',
    id: 'test12',
    content: '대충 잘 갔다옴3',
    img: '../test.jpg',
    date: '대충 현재 날짜 넣기',
    score: 5
  },
  {
    contentsid: '123',
    id: 'test2',
    content: '2 잘 갔다옴',
    img: '2 이미지 url',
    date: '3 현재 날짜 넣기',
    score: 5
  },
  {
    contentsid: 'CNTS_000000000022852',
    id: 'test1',
    content: '대충 잘 갔다옴',
    img: '../test.jpg',
    date: '대충 현재 날짜 넣기',
    score: 5
  },
  {
    contentsid: 'CNTS_000000000022852',
    id: 'test12',
    content: '대충 잘 갔다옴3',
    img: '../test.jpg',
    date: '대충 현재 날짜 넣기',
    score: 5
  },
  {
    contentsid: 'CNTS_000000000022852',
    id: 'test1',
    content: '대충 잘 갔다옴',
    img: '../test.jpg',
    date: '대충 현재 날짜 넣기',
    score: 5
  },
  {
    contentsid: 'CNTS_000000000022852',
    id: 'test12',
    content: '대충 잘 갔다옴3',
    img: '../test.jpg',
    date: '대충 현재 날짜 넣기',
    score: 5
  },
  {
    contentsid: '123',
    id: 'test2',
    content: '2 잘 갔다옴',
    img: '2 이미지 url',
    date: '3 현재 날짜 넣기',
    score: 5
  },
];